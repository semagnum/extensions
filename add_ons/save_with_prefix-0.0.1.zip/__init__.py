# save_with_prefix
# Copyright (C) 2024  SMagnusson
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program.
# If not, see <https://www.gnu.org/licenses/>.


from datetime import datetime
import os

import bpy

bl_info = {
    'name': 'Save with Prefix',
    'author': 'Spencer Magnusson',
    'version': (0, 0, 1),
    'blender': (4, 0, 0),
    'location': 'Prompt after you save',
    'description': 'Reminds users to save files with a user-defined prefix',
    'warning': 'Does rename files, be warned!',
    'tracker_url': 'https://projects.blender.org/SMagnusson/save_with_prefix/issues',
    'category': 'User Interface',
}


def _get_prefix(context, filepath):
    addon_preferences = context.preferences.addons[__package__].preferences

    if addon_preferences.prefix_type == 'DATE':
        creation_time = os.path.getctime(filepath)
        formatted_date = datetime.fromtimestamp(creation_time).strftime(addon_preferences.prefix_date)
        return formatted_date
    else:
        return addon_preferences.prefix_text


@bpy.app.handlers.persistent
def handler(self, _):
    filepath = bpy.data.filepath

    basename = os.path.basename(filepath)
    prefix = _get_prefix(bpy.context, filepath)

    if not basename.startswith(prefix):
        bpy.ops.wm.save_as_mainfile_with_prefix('INVOKE_DEFAULT')


class Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    prefix_type: bpy.props.EnumProperty(
        name='Prefix Type',
        description='Type of prefix',
        items=[
            ('DATE', 'Date', ''),
            ('TEXT', 'Text', 'U'),
        ],
        default='DATE',
    )

    prefix_text: bpy.props.StringProperty(
        name='Prefix Text',
        description='Prefix for new file name',
        default='SHOT_',
    )

    prefix_date: bpy.props.StringProperty(
        name='Prefix Date Format',
        description='Date format for new file name',
        default='%Y%m%d',
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, 'prefix_type')
        if self.prefix_type == 'DATE':
            layout.prop(self, 'prefix_date')
        else:
            layout.prop(self, 'prefix_text')


class SaveWithPrefix(bpy.types.Operator):
    bl_idname = 'wm.save_as_mainfile_with_prefix'
    bl_label = 'Save File with Prefix'

    def invoke(self, context, event):
        filepath = bpy.data.filepath
        basename = os.path.basename(filepath)
        prefix = _get_prefix(context, filepath)

        if basename.startswith(prefix):
            return {'CANCELLED'}

        return context.window_manager.invoke_confirm(
            self, event,
            title='Save with Prefix',
            message=f'Do you want to save your file as {prefix}_{basename}?',
        )

    def execute(self, context):
        filepath = bpy.data.filepath
        if not os.path.exists(filepath):
            return

        basename = os.path.basename(filepath)
        prefix = _get_prefix(context, filepath)
        my_dir = os.path.dirname(filepath)

        if basename.startswith(prefix):
            return {'CANCELLED'}

        new_filepath = os.path.join(my_dir, f'{prefix}_{basename}')

        # rename blend1, blend2, etc
        for other_file in os.listdir(my_dir):
            if other_file != basename and other_file.startswith(basename):
                backup_filepath = os.path.join(my_dir, f'{prefix}_{other_file}')
                os.rename(os.path.join(my_dir, other_file), backup_filepath)

        os.rename(filepath, new_filepath)
        return bpy.ops.wm.save_as_mainfile(filepath=new_filepath)

classes = (
    Preferences,
    SaveWithPrefix,
)

def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.app.handlers.save_post.append(handler)


def unregister():
    bpy.app.handlers.save_post.remove(handler)
    bpy.utils.unregister_class(SaveWithPrefix)
