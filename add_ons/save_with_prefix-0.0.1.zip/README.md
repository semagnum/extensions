# Save with Prefix

Reminds users to save files with a user-defined prefix. Can use date format or text prefix.
Once the user saves, a confirmation dialog is displayed asking if they want to save the file with the prefix.
If the user confirms, the file is saved again with the prefix (.blend1 files are also renamed with the prefix).

