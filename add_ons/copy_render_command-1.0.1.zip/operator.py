import bpy

from .generate_command import generate_command

def get_available_engines(self, context):
    """Gets available render engines.
    Unfortunately accessing enum_items only returns the default engine,
    so this hacky method will have to do for now.

    """
    engines = ('BLENDER_EEVEE_NEXT', 'BLENDER_WORKBENCH', 'CYCLES')
    try:
        bpy.context.scene.render.engine = ''
    except Exception as e:
        # TypeError: bpy_struct: item.attr = val: enum "" not found in ('BLENDER_EEVEE', 'BLENDER_WORKBENCH', 'CYCLES')
        # Parse the error and split the string
        engines = str(e).split("'")[1::2]

    def format(my_str: str):
        return my_str.replace('BLENDER_', '').replace('_', ' ').title()

    formatted_engines = [format(v) for v in engines]

    return [
        (v, name, name)
        for v, name in zip(engines, formatted_engines)
    ]


class CopyRenderCommand(bpy.types.Operator):
    # TODO support output path, file/output type, Cycles device
    bl_idname = "render.copy_console_command"
    bl_label = "Copy Render Console Command"
    bl_description = "Generates and copies console command to render to the clipboard"
    bl_options = {'REGISTER'}

    type: bpy.props.EnumProperty(
        name="Type",
        items=[
            ('-a', 'Animation', 'Render all frames'),
            ('-f', 'Image', 'Render a single frame'),
        ]
    )

    frame_current: bpy.props.IntProperty(
        name="Current Frame",
        default=1
    )
    override_frame_start: bpy.props.BoolProperty(default=False)
    frame_start: bpy.props.IntProperty(
        name="Start Frame",
        default=1
    )
    override_frame_end: bpy.props.BoolProperty(default=False)
    frame_end: bpy.props.IntProperty(
        name="End Frame",
        default=100
    )
    override_frame_step: bpy.props.BoolProperty(default=False)
    frame_step: bpy.props.IntProperty(
        name="Frame Step",
        default=1
    )

    override_scene: bpy.props.BoolProperty(default=False)
    scene: bpy.props.StringProperty(
        name="Scene",
        default="Scene"
    )

    override_threads: bpy.props.BoolProperty(default=False)
    threads: bpy.props.IntProperty(
        name="Threads",
        default=-1
    )

    override_engine: bpy.props.BoolProperty(default=False)
    engine: bpy.props.EnumProperty(
        items=get_available_engines
    )

    def inline_override_prop(self, layout, heading: str, override_attr: str, prop_attr: str):
        heading = layout.column(align=True, heading=heading)
        row = heading.row(align=True)
        row.prop(self, override_attr, text = '')
        sub = row.row()
        sub.active = getattr(self, override_attr)
        sub.prop(self, prop_attr, text='')


    def draw(self, context):
        layout = self.layout

        layout.use_property_split = True
        layout.use_property_decorate = False

        heading = layout.column(align=True, heading='Scene')
        row = heading.row(align=True)
        row.prop(self, 'override_scene', text='')
        sub = row.column(align=True)
        sub.active = self.override_scene
        sub.prop_search(self, 'scene', bpy.data, 'scenes', text='')

        self.inline_override_prop(layout, 'Engine', 'override_engine', 'engine')

        layout.prop(self, 'type', expand=True)

        if self.type == '-a':
            column = layout.column(align=True)
            self.inline_override_prop(column, 'Frame Start', 'override_frame_start', 'frame_start')
            self.inline_override_prop(column, 'End', 'override_frame_end', 'frame_end')
            self.inline_override_prop(column, 'Step', 'override_frame_step', 'frame_step')

            layout.separator()

            self.inline_override_prop(layout, 'Threads', 'override_threads', 'threads')

        elif self.type == '-f':
            layout.prop(self, 'frame_current')


    def invoke(self, context, event):
        self.type = '-f'

        # initialize values
        self.frame_start = context.scene.frame_start
        self.frame_end = context.scene.frame_end
        self.frame_step = context.scene.frame_step
        self.frame_current = context.scene.frame_current
        self.scene = context.scene.name
        self.threads = context.scene.render.threads
        self.engine = context.scene.render.engine

        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        if not bpy.data.is_saved:
            self.report({'ERROR'}, 'Save your file before rendering from command line!')
            return {'CANCELLED'}

        is_animation = self.type == '-a'

        cmd_args = {
            'blender_binary_path': bpy.app.binary_path,
            'blend_filepath': bpy.path.abspath(bpy.data.filepath),
            'is_animation': is_animation,
        }

        def add_override(override_attr, attr):
            if getattr(self, override_attr):
                cmd_args[attr] = str(getattr(self, attr))

        if is_animation:
            add_override('override_frame_start', 'frame_start')
            add_override('override_frame_end', 'frame_end')
            add_override('override_frame_step', 'frame_step')

            add_override('override_threads', 'threads')
        else:
            cmd_args['frame_current'] = str(self.frame_current)

        add_override('override_scene', 'scene')
        add_override('override_engine', 'engine')

        blender_cmd_str = generate_command(**cmd_args)

        context.window_manager.clipboard = blender_cmd_str

        self.report({'INFO'}, 'Render command copied to clipboard')

        return {'FINISHED'}
