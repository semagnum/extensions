#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy


class AnimationProperties:
    anim_enabled: bpy.props.BoolProperty(
        name='Frame Range',
        description='Query camera visibility over a frame range',
        options=set(),
        default=False
    )

    anim_method: bpy.props.EnumProperty(
        items=[
            ('SCENE', 'Scene', 'Use scene start and end frames'),
            ('CUSTOM', 'Custom', 'Use user-specified start and end frames'),
        ],
        name='Type',
        description='Which frame range to use',
        options=set(),
        default='SCENE'
    )

    anim_start_frame: bpy.props.IntProperty(default=1, name='Start Frame', options=set())
    anim_end_frame: bpy.props.IntProperty(default=250, name='End Frame', options=set())
    anim_frame_step: bpy.props.IntProperty(name='Frame Step', default=5, min=1, options=set())

    def draw_anim_props(self, layout):
        col = layout.column(heading='Frame Range')
        col.prop(self, 'anim_enabled', text='Query')

        col.prop(self, 'anim_method', expand=True)
        if self.anim_method == 'CUSTOM':
            frame_col = col.column(align=True)
            frame_col.prop(self, 'anim_start_frame', text='Frame Start')
            frame_col.prop(self, 'anim_end_frame', text='End')
            frame_col.prop(self, 'anim_frame_step', text='Step')
        else:
            col.prop(self, 'anim_frame_step', text='Frame Step')
