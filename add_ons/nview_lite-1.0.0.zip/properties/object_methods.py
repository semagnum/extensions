#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy

from .methods import DistanceMethodProperties, FrustumMethodProperties
from ..Constants import VIEW_FRUSTUM_OPTION, DISTANCE_OPTION


class ObjectMethodProperties(FrustumMethodProperties, DistanceMethodProperties):
    object_algorithm: bpy.props.EnumProperty(
        items=[
            (VIEW_FRUSTUM_OPTION, 'Frustrum', 'Cull objects outside camera view (no depth check)'),
            (DISTANCE_OPTION, 'Distance', 'Cull objects outside a given distance from the camera')
        ],
        name='Object Culling',
        description='Type of culling used to determine visibility',
        options=set(),
        default=VIEW_FRUSTUM_OPTION
    )

    def draw_obj_method_props(self, layout):
        layout.label(text='Object Method')
        row = layout.row()
        row.use_property_split = False
        row.prop(self, 'object_algorithm', expand=True)
        if self.object_algorithm == VIEW_FRUSTUM_OPTION:
            self.draw_frustum_props(layout)
        elif self.object_algorithm == DISTANCE_OPTION:
            self.draw_distance_props(layout)
