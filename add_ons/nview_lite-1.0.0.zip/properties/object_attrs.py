#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy

from .animation import AnimationProperties
from .camera import CameraProperties
from .object_methods import ObjectMethodProperties


class ObjectProperties(ObjectMethodProperties, AnimationProperties, CameraProperties):
    object_min_bound_box: bpy.props.FloatProperty(
        name='Min Bound Size',
        description='Smaller objects will be scaled up to this size for visibility tests',
        options=set(),
        min=0.0,
        default=0.001,
        soft_max=1.0,
        soft_min=0.0,
        step=1,
        precision=3,
        unit='LENGTH'
    )

    def draw_obj_props(self, layout, draw_anim_props=True):
        if draw_anim_props:
            self.draw_camera_props(layout)
            layout.separator()
            self.draw_anim_props(layout)
            layout.separator()

        box = layout.box()
        self.draw_obj_method_props(box)
        box.prop(self, 'object_min_bound_box')
