#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

from .animation import AnimationProperties
from .selection import SelectionProperties
from .camera import CameraElement, NV_UL_Cameras, CameraProperties
from .mesh_attrs import MeshProperties
from .object_attrs import ObjectProperties
