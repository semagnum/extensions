import bpy

from ..Constants import ACTIVE_CAMERA_OPTION, CUSTOM_CAMERA_OPTION


class CameraElement(bpy.types.PropertyGroup):
    is_selected: bpy.props.BoolProperty(name='Included', default=False)


class NV_UL_Cameras(bpy.types.UIList):
    """Blender UI List to display cameras in the redo operator"""

    def draw_item(self, context, layout, data, cameraprop, icon, active_data, active_propname, index):
        layout.prop(
            cameraprop, 'is_selected',
            text=cameraprop.name,
            toggle=True,
            icon='CHECKBOX_HLT' if cameraprop.is_selected else 'CHECKBOX_DEHLT'
        )

    def filter_items(self, context, data, propname):
        cameraprops = getattr(data, propname)
        helper_funcs = bpy.types.UI_UL_list

        # Default return values.
        flt_flags = []

        # Filtering by name
        if self.filter_name:
            flt_flags = helper_funcs.filter_items_by_name(
                self.filter_name, self.bitflag_filter_item,
                cameraprops, 'name'
            )

        if not flt_flags:
            flt_flags = [self.bitflag_filter_item] * len(cameraprops)

        _sort = [
            (idx, cameraprop.name)
            for idx, cameraprop in enumerate(cameraprops)
        ]
        flt_neworder = helper_funcs.sort_items_helper(_sort, lambda e: e[1:])

        return flt_flags, flt_neworder


class CameraProperties:
    custom_cameras: bpy.props.CollectionProperty(type=CameraElement)
    custom_cameras_active: bpy.props.IntProperty(default=0)

    camera_type: bpy.props.EnumProperty(
        items=[
            (ACTIVE_CAMERA_OPTION, 'Active camera', 'Active scene camera used at the given frame(s)', 'SCENE_DATA', 1),
            (CUSTOM_CAMERA_OPTION, 'Custom List', 'User-specified cameras', 'OUTLINER_OB_CAMERA', 2)
        ],
        name='Camera Type',
        description='Camera(s) an object must be visible from',
        options=set(),
        default=ACTIVE_CAMERA_OPTION
    )

    custom_operation: bpy.props.EnumProperty(
        items=[
            ('union', 'Union', 'Include objects visible from any of the selected cameras'),
            ('intersection', 'Intersection', 'Keep visible objects in common with all selected cameras')
        ],
        name='Operation',
        options=set(),
        default='union'
    )
    
    def initialize_custom_camera_list(self, context):
        objects = context.scene.objects
        self.custom_cameras.clear()

        # For each camera object, add a new item to toggle its usage
        for obj in objects:
            if obj.type != 'CAMERA':
                continue

            camera_item = self.custom_cameras.add()
            camera_item.name = obj.name
        if context.scene.camera is not None:
            self.custom_cameras[context.scene.camera.name].is_selected = True

    def draw_camera_props(self, layout):
        layout.prop(self, 'camera_type')
        if self.camera_type == CUSTOM_CAMERA_OPTION:
            layout.prop(self, 'custom_operation')
            # layout grid
            box = layout.box()
            box.use_property_split = False
            box.use_property_decorate = False
            box.template_list('NV_UL_Cameras', '', self, 'custom_cameras', self, 'custom_cameras_active')
