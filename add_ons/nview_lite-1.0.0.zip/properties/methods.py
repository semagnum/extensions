#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy


class FrustumMethodProperties:
    frustum_margin: bpy.props.FloatProperty(
        name='Margin',
        description='Margin for camera space culling',
        subtype='PERCENTAGE',
        options=set(),
        min=0.0,
        default=2.0,
        max=100.0,
        soft_max=5.0,
        soft_min=0.0,
        precision=1
    )

    def draw_frustum_props(self, layout):
        layout.prop(self, 'frustum_margin')


class DistanceMethodProperties:
    distance: bpy.props.FloatProperty(
        name='Distance',
        description='Maximum distance between the camera and objects',
        subtype='DISTANCE',
        options=set(),
        min=0.0,
        default=50.0,
        precision=2
    )

    def draw_distance_props(self, layout):
        layout.prop(self, 'distance')
