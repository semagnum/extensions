#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy

from .methods import FrustumMethodProperties
from ..Constants import VIEW_FRUSTUM_OPTION, BACKFACE_OPTION


class MeshMethodProperties(FrustumMethodProperties):
    mesh_algorithm: bpy.props.EnumProperty(
        items=[
            (VIEW_FRUSTUM_OPTION, 'Frustrum', 'Cull geometry outside camera view (no depth check)'),
            (BACKFACE_OPTION, 'Backface', 'Cull geometry facing away from the camera'),
        ],
        name='Mesh Culling',
        description='Type of culling used to determine visibility',
        options=set(),
        default=VIEW_FRUSTUM_OPTION
    )

    def draw_mesh_method_props(self, layout):
        layout.label(text='Mesh Method')
        row = layout.row()
        row.use_property_split = False
        row.prop(self, 'mesh_algorithm', expand=True)
        if self.mesh_algorithm == VIEW_FRUSTUM_OPTION:
            self.draw_frustum_props(layout)
