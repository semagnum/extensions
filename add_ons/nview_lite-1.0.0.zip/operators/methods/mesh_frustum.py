#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

from mathutils import Vector
from mathutils.geometry import normal

from .util_main import add_margin, is_segment_in_planes, side_of_plane


def vertex_in_planes(vertex, obj, planes):
    world_vert = get_world_vert(vertex, obj)
    epsilon = -0.00001

    # one point must be within all planes
    return all(
        side_of_plane(p, world_vert) > epsilon for p in planes
    )


def get_world_vert(vertex, obj):
    matrix = obj.matrix_world
    return matrix @ Vector(vertex.co)


def camera_as_planes(context, camera, margin):
    """
    Return planes in world-space which represent the camera view bounds.
    """
    matrix = camera.matrix_world
    active_camera = camera.data
    frame = active_camera.view_frame(scene=context.scene)
    if margin > 0:
        frame = list(map(add_margin, frame, [margin] * 4))
    frame = [matrix @ v for v in frame]
    origin = matrix.to_translation()

    planes = []
    is_perspective = (active_camera.type != 'ORTHO')
    for i in range(4):
        # find the 3rd point to define the planes direction
        if is_perspective:
            frame_other = origin
        else:
            frame_other = frame[i] + matrix.col[2].xyz

        n = normal((frame_other, frame[i - 1], frame[i]))
        d = -n.dot(frame_other)
        planes.append((n, d))

    if not is_perspective:
        # add a 5th plane to ignore objects behind the view
        n = normal((frame[0], frame[1], frame[2]))
        d = -n.dot(origin)
        planes.append((n, d))

    return planes


def face_intersecting_planes(face, obj, planes):
    world_vertices = [get_world_vert(v, obj) for v in face.verts]
    vert_size = len(world_vertices)
    return any(
        is_segment_in_planes(world_vertices[i], world_vertices[j], planes)
        for i in range(vert_size - 1)
        for j in range(i + 1, vert_size)
    )


def detect_frustum(context, mesh_object, viable_geo, camera, select_mode, frustum_margin: float, **_kwargs):
    margin = (frustum_margin / 100.0) / 2.0

    planes = camera_as_planes(context, camera, margin)
    if select_mode == 'VERT':
        return [v for v in viable_geo if vertex_in_planes(v, mesh_object, planes)]
    if select_mode in ('FACE', 'EDGE'):
        return [f for f in viable_geo if face_intersecting_planes(f, mesh_object, planes)]
