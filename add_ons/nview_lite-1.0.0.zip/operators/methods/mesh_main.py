#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

import bmesh

from .util_main import get_cameras, get_frames, get_active_camera_change_frames
from ...Constants import ACTIVE_CAMERA_OPTION, BACKFACE_OPTION, CUSTOM_CAMERA_OPTION, VIEW_FRUSTUM_OPTION

from .mesh_frustum import detect_frustum
from .mesh_backface import detect_backface

GET_MESH_METHOD = {
    VIEW_FRUSTUM_OPTION: detect_frustum,
    BACKFACE_OPTION: detect_backface
}


def get_obj_bmesh(mesh_object, use_edit_mesh: bool):
    """Gets BMesh object from edit mesh or generates a new one from mesh data.

    :param mesh_object: Blender object of mesh type.
    :param use_edit_mesh: use existing BMesh from mesh edit mode instead of a new BMesh.
    :return: BMesh object for mesh
    """
    if use_edit_mesh:
        obj_bmesh = bmesh.from_edit_mesh(mesh_object.data)
    else:
        obj_bmesh = bmesh.new()
        obj_bmesh.from_mesh(mesh_object.data)

    return obj_bmesh


def get_selected_geo(obj_bmesh, select_mode: str):
    """Get relevant selected geometry of type based on selection mode.

    :param obj_bmesh: BMesh object for mesh
    :param select_mode: mesh selection mode, in {'FACE', 'EDGE', 'VERT'}
    :return: list of geometry
    :except ValueError if selection mode is not in {'FACE', 'EDGE', 'VERT'}
    """
    if select_mode == 'EDGE':
        viable_geo = [edge for edge in obj_bmesh.edges if edge.select]
    elif select_mode == 'FACE':
        viable_geo = [face for face in obj_bmesh.faces if face.select]
    elif select_mode == 'VERT':
        viable_geo = [vert for vert in obj_bmesh.verts if vert.select]
    else:
        raise ValueError('Invalid select mode!')

    return viable_geo


def get_all_geo(obj_bmesh, select_mode: str):
    """Get all geometry of type based on selection mode.

    :param obj_bmesh: BMesh object for mesh
    :param select_mode: mesh selection mode, in {'FACE', 'EDGE', 'VERT'}
    :return: list of geometry
    :except ValueError if selection mode is not in {'FACE', 'EDGE', 'VERT'}
    """
    if select_mode == 'EDGE':
        return obj_bmesh.edges
    elif select_mode == 'FACE':
        return obj_bmesh.faces
    elif select_mode == 'VERT':
        return obj_bmesh.verts
    else:
        raise ValueError('Invalid select mode!')


def mesh_main(context, camera_type: str, custom_cameras: list, custom_operation: str, anim_method: str,
              mesh_object, anim_enabled: bool, use_edit_mesh=True, select_mode='FACE', **kwargs):
    """Evaluates visibility of mesh geometry.

    :param context: Blender context
    :param camera_type: Determines to either use active camera or a custom camera list
    :param custom_cameras: custom camera list, used if camera_type is CUSTOM_CAMERA_OPTION
    :param custom_operation: determines union or intersection operation between frames
    :param anim_method: determines using scene or custom frame range
    :param mesh_object: Blender object of mesh type
    :param anim_enabled: evaluate mesh over multiple frames
    :param use_edit_mesh: use edit mode BMesh instead of a new BMesh
    :param select_mode: mesh selection mode
    :return: tuple of data
    (list of selected geometry,
    True if all geometry was found (False otherwise),
    object's BMesh,
    list of all geometry)
    """

    obj_bmesh = get_obj_bmesh(mesh_object, use_edit_mesh)
    if use_edit_mesh:
        cur_select_mode = list(obj_bmesh.select_mode)[0]
        viable_geo = get_selected_geo(obj_bmesh, cur_select_mode)
    else:  # if not in edit mode, use all geometry
        cur_select_mode = select_mode
        viable_geo = get_all_geo(obj_bmesh, cur_select_mode)

    is_intersection = (camera_type == CUSTOM_CAMERA_OPTION) and custom_operation == 'intersection'
    kwargs.update({'obj_bmesh': obj_bmesh})

    if anim_enabled:
        result, all_found = mesh_main_animation(context, mesh_object,
                                                camera_type, custom_cameras, is_intersection, anim_method,
                                                cur_select_mode, viable_geo, **kwargs)
    else:
        result = set()
        mesh_algorithm = kwargs.get('mesh_algorithm', '')
        detection_method = GET_MESH_METHOD[mesh_algorithm]

        for idx, camera in enumerate(get_cameras(context, custom_cameras, camera_type)):
            cur_result = detection_method(context, mesh_object, viable_geo, camera, cur_select_mode, **kwargs)
            if is_intersection and idx != 0:
                result = result.intersection(cur_result)
            else:
                result = result.union(cur_result)
        all_found = len(result) == len(viable_geo)
        result = list(result)

    return result, all_found, obj_bmesh, viable_geo


def mesh_main_animation(context, mesh_object,
                        camera_type: str, custom_cameras: list, is_intersection: bool, anim_method: str,
                        selection_mode: str, viable_geo: list, **kwargs):
    """Evaluates visibility of mesh geometry over a frame range.

    :param context: Blender context
    :param mesh_object: Blender object of mesh type
    :param camera_type: Determines to either use active camera or a custom camera list
    :param custom_cameras: custom camera list, used if camera_type is CUSTOM_CAMERA_OPTION
    :param is_intersection: use intersection operation for merging lists of visible objects per frame, union otherwise
    :param anim_method: determines using scene or custom frame range
    :param selection_mode: mesh selection mode
    :param viable_geo: list of selected geometry
    :return: tuple of data: (list of selected geometry, True if all geometry was found (False otherwise))
    """
    mesh_algorithm = kwargs.get('mesh_algorithm', '')

    prev_frame = context.scene.frame_current
    frame_start, frame_end, frame_step = get_frames(
        context, anim_method,
        kwargs.get('anim_start_frame'),
        kwargs.get('anim_end_frame'),
        kwargs.get('anim_frame_step')
    )

    frame_range = list(range(frame_start, frame_end + 1, frame_step))
    if camera_type == ACTIVE_CAMERA_OPTION and any(m.camera is not None for m in context.scene.timeline_markers):
        frame_range = set(frame_range).union(
            get_active_camera_change_frames(context.scene.timeline_markers, frame_start, frame_end)
        )

    scene = context.scene
    index_dict = {v.index: v for v in viable_geo}
    selected = {}

    detection_method = GET_MESH_METHOD[mesh_algorithm]

    wm = context.window_manager
    wm.progress_begin(frame_start, frame_end)
    all_found = False

    for i in frame_range:
        if len(index_dict.values()) == 0:
            all_found = True
            break

        scene.frame_set(i)
        context.view_layer.update()

        found = set()
        for idx, camera in enumerate(get_cameras(context, custom_cameras, camera_type)):
            frame_result = detection_method(context, mesh_object, index_dict.values(),
                                            camera, selection_mode, **kwargs)
            if is_intersection and idx != 0:
                found = found.intersection(frame_result)
            else:
                found = found.union(frame_result)

        selected.update({v.index: v for v in found})

        # removes selected objects to save calculation later
        for f in found:
            index_dict.pop(f.index, None)

            wm.progress_update(i)

    wm.progress_end()

    context.scene.frame_set(prev_frame)

    return list(selected.values()), all_found
