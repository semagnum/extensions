#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


from mathutils import Vector


def detect_distance(_context, objects: list, camera, distance, **_kwargs):
    """Detects objects within a specified distance from the camera.

    :param _context: Blender context
    :param objects: list of Blender objects
    :param camera: Blender camera
    :param distance: maximum allowed distance from an object to the camera
    :return: list of objects close enough to the camera
    """
    max_distance = distance
    camera_location = camera.matrix_world.to_translation()
    return [
        obj
        for obj in objects
        if any(
            ((obj.matrix_world @ Vector(corner)) - camera_location).length < max_distance
            for corner in obj.bound_box
        )
    ]
