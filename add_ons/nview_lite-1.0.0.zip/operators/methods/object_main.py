#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

from ..model_object import ObjModel
from ...Constants import (
    ACTIVE_CAMERA_OPTION,
    CUSTOM_CAMERA_OPTION,
    DISTANCE_OPTION,
    VIEW_FRUSTUM_OPTION,
)
from .util_main import get_active_camera_change_frames, get_cameras, get_frames

from .object_frustum import detect_frustum
from .object_distance import detect_distance

GET_OBJECT_METHOD = {
    VIEW_FRUSTUM_OPTION: detect_frustum,
    DISTANCE_OPTION: detect_distance,
}


def generate_object_models(objects, object_min_bound_box):
    """
    Returns model classes of selected objects, excluding instanced objects
    :param objects: list of objects
    :param object_min_bound_box: minimum allowed bounding box size for objects without one defined
    :return: list of objects from the scene as models, with a generated bounding box
    """
    return [ObjModel(obj, object_min_bound_box) for obj in objects]


def obj_main(context, objects,
             camera_type: str, custom_cameras: list, custom_operation: str,
             anim_enabled: bool,
             object_algorithm: str,
             object_min_bound_box: float,
             return_model=False,
             **kwargs):
    """Evaluates visibility of Blender objects in a given scene.

    :param context: Blender context
    :param objects: list of Blender objects to query
    :param camera_type: Determines to either use active camera or a custom camera list
    :param custom_cameras: custom camera list, used if camera_type is CUSTOM_CAMERA_OPTION
    :param custom_operation: determines union or intersection operation between frames
    :param anim_enabled: evaluate mesh over multiple frames
    :param object_algorithm: name of algorithm to use
    :param object_min_bound_box: minimum bounding box size for objects without it defined
    :param return_model: True to return ObjModel-wrapped list of objects (to use bounding box or further evaluations)
    :return: list of visible objects
    """
    is_intersection = (camera_type == CUSTOM_CAMERA_OPTION) and custom_operation == 'intersection'
    objects = generate_object_models(objects, object_min_bound_box)

    if anim_enabled:
        result = obj_main_animation(context, objects, object_algorithm,
                                    camera_type, custom_cameras, is_intersection, **kwargs)
    else:
        result = obj_main_single_frame(context, objects, object_algorithm,
                                       camera_type, custom_cameras, is_intersection, **kwargs)

    return result if return_model else [o.obj for o in result]


def obj_main_animation(context, objects: list, object_algorithm: str,
                       camera_type: str, custom_cameras: list, is_intersection: bool, anim_method: str, **kwargs):
    """Evaluates visibility of Blender objects in a given scene for multiple frames.

    :param context: Blender context
    :param objects: list of Blender objects to query
    :param object_algorithm: name of algorithm to use
    :param camera_type: Determines to either use active camera or a custom camera list
    :param custom_cameras: custom camera list, used if camera_type is CUSTOM_CAMERA_OPTION
    :param is_intersection: use intersection operation for merging lists of visible objects per frame, union otherwise
    :param anim_method: determines using scene or custom frame range

    :return: list of visible objects
    """
    scene = context.scene
    view_layer = context.view_layer
    wm = context.window_manager

    prev_frame = context.scene.frame_current
    frame_start, frame_end, frame_step = get_frames(
        context, anim_method,
        kwargs.get('anim_start_frame'),
        kwargs.get('anim_end_frame'),
        kwargs.get('anim_frame_step')
    )
    obj_dict = {o.name: o for o in objects}
    selected_objs = {}

    keyframe_range = list(range(frame_start, frame_end + 1, frame_step))
    if camera_type == ACTIVE_CAMERA_OPTION and any(m.camera is not None for m in context.scene.timeline_markers):
        keyframe_range = set(keyframe_range).union(
            get_active_camera_change_frames(context.scene.timeline_markers, frame_start, frame_end)
        )

    detection_method = GET_OBJECT_METHOD[object_algorithm]

    frame_count = len(keyframe_range)
    wm.progress_begin(0, frame_count)

    for keyframe_idx, i in enumerate(keyframe_range):
        if len(obj_dict.values()) == 0:
            break

        scene.frame_set(i)
        view_layer.update()

        found_objects = set()
        for idx, camera in enumerate(get_cameras(context, custom_cameras, camera_type)):
            frame_result = detection_method(context, obj_dict.values(), camera, **kwargs)
            if is_intersection and idx != 0:
                found_objects = found_objects.intersection(frame_result)
            else:
                found_objects = found_objects.union(frame_result)

        selected_objs.update({o.name: o for o in found_objects})

        # removes selected objects to save calculation later
        for o in found_objects:
            obj_dict.pop(o.name, None)

        wm.progress_update(keyframe_idx)

    wm.progress_end()
    result = list(selected_objs.values())

    # reset to original frame
    context.scene.frame_set(prev_frame)

    return result


def obj_main_single_frame(context, objects: list, object_algorithm: str,
                          camera_type: str, custom_cameras: list, is_intersection: bool, **kwargs):
    """Evaluates visibility of Blender objects in a given scene for a single frame.

    :param context: Blender context
    :param objects: list of Blender objects to query
    :param object_algorithm: name of algorithm to use
    :param camera_type: Determines to either use active camera or a custom camera list
    :param custom_cameras: custom camera list, used if camera_type is CUSTOM_CAMERA_OPTION
    :param is_intersection: use intersection operation for merging lists of visible objects per frame, union otherwise
    :return: list of visible objects
    """
    result = set()
    detection_method = GET_OBJECT_METHOD[object_algorithm]

    for idx, camera in enumerate(get_cameras(context, custom_cameras, camera_type)):
        cur_result = detection_method(context, objects, camera, **kwargs)
        if is_intersection and idx != 0:
            result = result.intersection(cur_result)
        else:
            result = result.union(cur_result)
    result = list(result)
    return result
