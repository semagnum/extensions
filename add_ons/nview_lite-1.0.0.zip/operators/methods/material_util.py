#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

import bpy

import math

IS_BPY_V3 = bpy.app.version < (4, 0, 0)

NODE_TYPE_CONTAINS_ALPHA = {
    'BSDF_GLASS',
    'BSDF_TRANSPARENT',
    'BSDF_TRANSLUCENT',
    'PRINCIPLED_VOLUME',
    'VOLUME_ABSORPTION',
    'VOLUME_SCATTER',
}


def node_uses_transparency(curr_node: bpy.types.Node) -> bool:
    """Get all nodes currently used within a node tree.

    :param curr_node: node to start with.
    :return: True if node is dependent on transparency, False otherwise
    """
    if not curr_node.mute:
        if hasattr(curr_node, 'node_tree'):
            return any(
                    node_uses_transparency(output_node)
                    for output_node in curr_node.node_tree.nodes
                    if 'Output' in output_node.bl_idname
            )
        elif curr_node.type in NODE_TYPE_CONTAINS_ALPHA:
            return True
        if 'BSDF_' in curr_node.type:
            if curr_node.type == 'BSDF_PRINCIPLED':
                transmission_socket = curr_node.inputs[17]
                alpha_socket = curr_node.inputs[21] if IS_BPY_V3 else curr_node.inputs[4]
                return (alpha_socket.is_linked or not math.isclose(alpha_socket.default_value, 1.0)
                        or transmission_socket.is_linked or transmission_socket.default_value > 0.0)
            return False

    return any(node_uses_transparency(link.from_node)
               for node_input in curr_node.inputs
               for link in node_input.links
               if node_input.is_linked)


def material_uses_transparency(material: bpy.types.Material) -> bool:
    """Tests if material contains transparency.

    :param material: material to test
    :return: True if material is dependent on transparency, False otherwise
    """
    if not material.use_nodes:
        return False

    return any(
        node_uses_transparency(node)
        for node in material.node_tree.nodes
        if 'Output' in node.bl_idname
    )


def material_from_face(obj: bpy.types.Object, face_idx: int) -> bpy.types.Material:
    """Gets material from object, using the face index if possible.

    :param obj: Blender object
    :param face_idx: mesh face index
    :return: the Material of the object or face hit, or None if no materials detected
    """
    try:  # for non-mesh objects - just get material
        if len(obj.data.materials):
            return obj.data.materials[0]
    except AttributeError:
        pass

    try:  # mesh method - get material from face
        if not obj.material_slots:
            return None
        material_idx = obj.data.polygons[face_idx].material_index
        return obj.material_slots[material_idx].material
    except AttributeError:
        pass

    return None
