#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

import math

from mathutils import Vector

from ...Constants import ACTIVE_CAMERA_OPTION, CUSTOM_CAMERA_OPTION

def get_sign(v):
    return 1 if v >= 0 else -1


def add_margin(vector, margin):
    x_sign, y_sign = get_sign(vector.x), get_sign(vector.y)
    return Vector(((abs(vector.x) + margin) * x_sign, (abs(vector.y) + margin) * y_sign, vector.z))


def side_of_plane(p, v):
    return p[0].dot(v) + p[1]


def is_segment_in_planes(p1, p2, planes):
    dp = p2 - p1

    p1_fac = 0.0
    p2_fac = 1.0

    for p in planes:
        div = dp.dot(p[0])
        if not math.isclose(div, 0.0):
            t = -side_of_plane(p, p1)
            if div > 0.0:
                # clip p1 lower bounds
                if t >= div:
                    return False
                if t > 0.0:
                    fac = (t / div)
                    p1_fac = max(fac, p1_fac)
                    if p1_fac > p2_fac:
                        return False
            elif div < 0.0:
                # clip p2 upper bounds
                if t > 0.0:
                    return False
                if t > div:
                    fac = (t / div)
                    p2_fac = min(fac, p2_fac)
                    if p1_fac > p2_fac:
                        return False

    p1_clip = p1.lerp(p2, p1_fac)
    p2_clip = p1.lerp(p2, p2_fac)
    epsilon = -0.1
    return all(side_of_plane(p, p1_clip) > epsilon and side_of_plane(p, p2_clip) > epsilon for p in planes)


def point_in_object(obj, pt):
    """Check if a given point is within an object's bounding box.
    Calculated in the object's local space.

    :param obj: Blender object
    :param pt: point in world space, as a Vector
    :return: True if point is within object's bounding box, False otherwise
    """
    xs, ys, zs = zip(*obj.bound_box)
    pt_local = obj.matrix_world.inverted_safe() @ pt
    return (min(xs) <= pt_local.x <= max(xs) and
            min(ys) <= pt_local.y <= max(ys) and
            min(zs) <= pt_local.z <= max(zs))


def get_cameras(context, custom_cameras: list, camera_type: str):
    """Get camera to use for visibility check.

    :param context: Blender context
    :param custom_cameras: if camera_type is CUSTOM_CAMERA_OPTION, use selected cameras from this list
    :param camera_type: name of camera type, in {ACTIVE_CAMERA_OPTION, CUSTOM_CAMERA_OPTION}
    :return: list of cameras
    """
    scene = context.scene
    switch = {
        ACTIVE_CAMERA_OPTION: [scene.camera],
        CUSTOM_CAMERA_OPTION: [
            scene.objects[camera_prop.name]
            for camera_prop in custom_cameras
            if camera_prop.is_selected
        ]
    }
    result = switch.get(camera_type)
    if len(result) == 0 or any(r is None for r in result):
        raise ValueError('Camera not found!')
    yield from result


def get_resolution(context):
    """Get resolution from current scene.

    :param context: Blender context
    :return: tuple representing x and y resolution
    """
    render = context.scene.render
    percentage = render.resolution_percentage / 100
    return int(render.resolution_x * percentage), int(render.resolution_y * percentage)


def reflect_vector(input_vector, normal):
    """Reflects a vector on the given normal."""
    dn = 2 * input_vector.dot(normal)
    return input_vector - normal * dn


def get_frames(context, frame_type: str, custom_start: int, custom_end: int, frame_step: int):
    if frame_type == 'SCENE':
        scene = context.scene
        return scene.frame_start, scene.frame_end, frame_step
    else:
        return custom_start, custom_end, frame_step


def get_active_camera_change_frames(timeline_markers, frame_start, frame_end) -> set:
    """

    :param timeline_markers: list of Blender timeline markers, referencing its frame and reference to its camera
    :param frame_start: starting frame of animation query
    :param frame_end: ending frame of animation query
    :return:
    """
    prev_camera = None
    frames = set()
    for m in timeline_markers:
        if (
                (frame_start <= m.frame <= frame_end) and
                (prev_camera is None or (m.camera is not None and m.camera.name != prev_camera))
        ):
            frames.add(m.frame)
            prev_camera = m.camera.name
    return frames


def camera_pixel_origin_and_direction(camera, x, y, z, is_ortho: bool):
    camera_matrix = camera.matrix_world
    camera_quaternion = camera_matrix.to_quaternion()
    if is_ortho:
        camera_translation = camera_matrix @ Vector((x, y, 0))
        pixel_vector = Vector((0, 0, -1))
    else:
        camera_translation = camera_matrix.to_translation()
        pixel_vector = Vector((x, y, z))

    pixel_vector.rotate(camera_quaternion)

    return camera_translation, pixel_vector
