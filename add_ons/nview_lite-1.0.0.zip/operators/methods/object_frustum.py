#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


from mathutils.geometry import normal
from mathutils import Vector

from .util_main import side_of_plane, is_segment_in_planes, add_margin, point_in_object


def object_in_planes(obj, planes):
    """Detects if an object is within or intersects a set of planes.

    :param obj: Blender object
    :param planes: list of tuples (normal, center) representing planes
    :return: True if object is contained within or intersects planes, False otherwise
    """
    matrix = obj.matrix_world
    box = [matrix @ Vector(v) for v in obj.bound_box]
    epsilon = -0.00001
    for v in box:
        if all(side_of_plane(p, v) > epsilon for p in planes):
            # one point is within all planes
            return True

    # possible one of our edges/triangles intersect
    box_size = len(box)
    edges = ((i, j) for i in range(box_size - 1) for j in range(i + 1, box_size))

    return any(
        is_segment_in_planes(box[e[0]], box[e[1]], planes)
        for e in edges
    )


def object_in_front_of_camera(obj, camera):
    """Detects if object is in front of the camera,
     using dot product on each of the object's bounding box with the camera's forward vector.

    :param obj: Blender object to detect
    :param camera: Blender camera
    :return: True if in front of camera, False otherwise
    """
    matrix = obj.matrix_world
    box = [matrix @ Vector(v) for v in obj.bound_box]
    camera_location = camera.matrix_world.to_translation()
    v_rays = [(v - camera_location).normalized() for v in box]

    camera_normal = (camera.matrix_world @ Vector((0, 0, -1)) - camera_location).normalized()

    return any((camera_normal.dot(v) > 0 for v in v_rays))


def camera_as_planes(context, camera, margin):
    """Return planes in world-space which represent the camera view bounds.

    :param context: Blender context
    :param camera: Blender camera
    :param margin: margin to extend camera view bound size
    :return: list of tuples (normal, center) representing planes
    """
    matrix = camera.matrix_world
    active_camera = camera.data
    frame = active_camera.view_frame(scene=context.scene)
    if margin > 0:
        frame = list(map(add_margin, frame, [margin] * 4))
    frame = [matrix @ v for v in frame]
    origin = matrix.to_translation()

    planes = []
    is_perspective = (active_camera.type != 'ORTHO')
    for i in range(4):
        # find the 3rd point to define the planes direction
        if is_perspective:
            frame_other = origin
        else:
            frame_other = frame[i] + matrix.col[2].xyz

        n = normal((frame_other, frame[i - 1], frame[i]))
        d = -n.dot(frame_other)
        planes.append((n, d))

    if not is_perspective:
        # add a 5th plane to ignore objects behind the view
        n = normal((frame[0], frame[1], frame[2]))
        d = -n.dot(origin)
        planes.append((n, d))

    return planes


def detect_frustum(context, objects: list, camera, frustum_margin: float, **_kwargs):
    """Detects if objects are within camera frustum.

    :param context: Blender context
    :param objects: list of Blender objects
    :param camera: Blender camera
    :param frustum_margin: margin to extend frustum space, to compensate for objects just outside of camera
    :return: list of objects within or intersecting camera frustum
    """
    margin = (frustum_margin / 100.0) / 2.0
    cam_origin = camera.matrix_world.to_translation()
    planes = camera_as_planes(context, camera, margin)
    return [obj for obj in objects
            if object_in_front_of_camera(obj, camera) and
            (point_in_object(obj, cam_origin) or object_in_planes(obj, planes))]
