#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

from mathutils.geometry import normal


def is_backface(normal, pos, camera_pos):
    """
    Check if the normal of the mesh is facing away from the camera.
    Args:
        :param normal: a Vector
        :param pos: position of the normal
        :param camera_pos: camera's position
    :return: if the normal is facing away from the camera
    """
    camera_norm = (pos - camera_pos).normalized()
    return normal.dot(camera_norm) > 0


def detect_backface(context, mesh_object, viable_geo, camera, select_mode, **_kwargs):
    if select_mode not in {'VERT', 'FACE'}:
        raise ValueError("Invalid select mode: %s - must be vertex or face selection" % select_mode)

    if camera.type == 'ORTHO':
        frame = camera.data.view_frame(scene=context.scene)
        ortho_camera_norm = normal((frame[0], frame[1], frame[2]))
        ortho_camera_norm.rotate(camera.matrix_world.to_quaternion())

        if select_mode == 'VERT':
            return [v for v in viable_geo
                    if v.normal.dot(ortho_camera_norm) > 0]
        elif select_mode == 'FACE':
            return [f for f in viable_geo
                    if f.normal.dot(ortho_camera_norm) > 0]
    else:
        camera_position = camera.matrix_world.to_translation()
        obj_matrix = mesh_object.matrix_world.inverted_safe()
        relative_camera_position = obj_matrix @ camera_position

        if select_mode == 'VERT':
            return [
                v for v in viable_geo
                if not is_backface(v.normal, v.co, relative_camera_position)
            ]
        elif select_mode == 'FACE':
            return [
                f for f in viable_geo
                if not all(is_backface(f.normal, v.co, relative_camera_position) for v in f.verts)
            ]
