#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy
import bmesh

from .methods.mesh_main import mesh_main
from .op_input import OperatorSkip
from ..properties import MeshProperties, SelectionProperties


class NV_OT_SelectMesh(bpy.types.Operator, OperatorSkip, MeshProperties, SelectionProperties):
    bl_idname = 'nview_lite.select_mesh'
    bl_label = 'Deselect Geometry Outside View'
    bl_description = 'Selects geometry visible by the camera'
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        self.draw_selection_props(layout)
        layout.separator()
        self.draw_mesh_props(self.layout)

    def execute(self, context):
        if self.if_skippable(context.window_manager, self.bl_idname, self.as_keywords()):
            self.report({'INFO'}, 'No active properties changed, skipping operation')
            return {'CANCELLED'}

        # force depsgraph and matrix updates for 4.2
        # https://projects.blender.org/blender/blender/issues/125335
        context.evaluated_depsgraph_get()

        try:
            visible, _, _, all_of_them = mesh_main(context=context, mesh_object=context.edit_object, use_edit_mesh=True, **self.as_keywords())
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        bpy.ops.mesh.select_all(action='DESELECT')
        visible_indices = {v.index for v in visible}

        for a in all_of_them:
            is_visible = a.index in visible_indices
            should_select = is_visible != self.invert
            a.select_set(should_select)

        bmesh.update_edit_mesh(context.edit_object.data, loop_triangles=False, destructive=False)

        self.update_prev_data(context.window_manager, self.as_keywords(), self.bl_idname)

        return {'FINISHED'}
