#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

from .op_coll import find_instanced_objs_in_colls
from .. import __package__ as base_package


class OperatorSkip:
    """Allows operators to skip running if only inactive settings are changed.
    Allows users to 'prep' certain settings before turning it all on."""

    def invoke(self, context, _event):
        wm = context.window_manager
        wm.prev_run_data = '{}'
        wm.prev_run_operator = ''

        self.initialize_custom_camera_list(context)

        if context.preferences.addons[base_package].preferences.use_dialog_box:
            return wm.invoke_props_dialog(self)

        return self.execute(context)

    def if_skippable(self, window_manager, bl_idname, curr_data) -> bool:
        if window_manager.prev_run_operator != bl_idname:
            return False

        import ast
        pre_run_data: dict = ast.literal_eval(window_manager.prev_run_data)

        if not pre_run_data:
            return False

        sanitized_data = curr_data.copy()
        sanitized_data['custom_cameras'] = {
            custom_camera_item.name: custom_camera_item.is_selected
            for custom_camera_item in curr_data['custom_cameras']
        }

        # since animation is disabled, exclude animation related properties
        data_to_check = list(pre_run_data)
        if sanitized_data['anim_enabled'] == pre_run_data['anim_enabled'] == False:
            data_to_check = [key for key in data_to_check
                             if key == 'anim_enabled' or 'anim' not in key]

        # if all other properties are the same, then it can be skipped
        return all(sanitized_data[key] == pre_run_data[key] for key in data_to_check)

    def update_prev_data(self, window_manager, curr_data: dict, bl_idname):
        """Updates data of the previously run operator and its properties."""
        sanitized_data = curr_data.copy()
        sanitized_data['custom_cameras'] = {
            custom_camera_item.name: custom_camera_item.is_selected
            for custom_camera_item in curr_data['custom_cameras']
        }
        window_manager.prev_run_data = str(sanitized_data)
        window_manager.prev_run_operator = bl_idname


def get_selected_objects(context):
    """
    Returns model classes of selected objects, excluding instanced objects
    :param context: Blender context
    :return: list of Objects from the scene
    """
    instanced_objs = set(find_instanced_objs_in_colls(context.view_layer.layer_collection.collection))
    return [obj for obj in context.selected_objects if obj not in instanced_objs]
