#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy

from .methods.object_main import obj_main
from .op_input import get_selected_objects, OperatorSkip
from .op_coll import coll_iter
from ..properties import ObjectProperties


class NV_OT_ColVis(bpy.types.Operator, OperatorSkip, ObjectProperties):
    bl_idname = 'nview_lite.col_visibility'
    bl_label = 'Set Collection nView'
    bl_description = 'Hides collections where none of its objects are visible by the camera'
    bl_options = {'REGISTER', 'UNDO'}

    exclude: bpy.props.BoolProperty(
        name='View Layer',
        description='Exclude invisible collections as view layers',
        options=set(),
        default=True
    )

    selectable: bpy.props.BoolProperty(
        name='Selectable',
        description='Invisible collections cannot be selected',
        options=set(),
        default=True
    )

    visible: bpy.props.BoolProperty(
        name='Visible',
        description='Invisible collections are hidden temporarily in viewport',
        options=set(),
        default=True
    )

    viewport: bpy.props.BoolProperty(
        name='Viewport',
        description='Invisible collections are disabled globally in the viewport',
        options=set(),
        default=True
    )

    render: bpy.props.BoolProperty(
        name='Render',
        description='Invisible collections are disabled globally in renders',
        options=set(),
        default=True
    )

    def draw(self, _context):
        layout = self.layout
        layout.use_property_split = True
        column = layout.column(heading='Visibility')
        column.prop(self, 'exclude')
        column.prop(self, 'selectable')
        column.prop(self, 'visible')
        column.prop(self, 'viewport')
        column.prop(self, 'render')

        layout.separator()
        self.draw_obj_props(layout)

    def make_col_visible(self, layer_col):
        if self.exclude:
            layer_col.exclude = False
        if self.visible:
            layer_col.hide_viewport = False
        if self.selectable:
            layer_col.collection.hide_select = False
        if self.viewport:
            layer_col.collection.hide_viewport = False
        if self.render:
            layer_col.collection.hide_render = False

    def make_col_invisible(self, layer_col):
        if self.exclude:
            layer_col.exclude = True
        if self.visible:
            layer_col.hide_viewport = True
        if self.selectable:
            layer_col.collection.hide_select = True
        if self.viewport:
            layer_col.collection.hide_viewport = True
        if self.render:
            layer_col.collection.hide_render = True

    def collection_visibility(self, context, visible_objects, viable_objects):
        obj_names = {obj.name for obj in visible_objects}

        viable_obj_names = {obj.name for obj in viable_objects}

        for layer_col in coll_iter(context.view_layer.layer_collection):
            has_viable_objects = any((obj.name in viable_obj_names for obj in layer_col.collection.all_objects))
            if has_viable_objects:
                has_visible_objects = any((obj.name in obj_names for obj in layer_col.collection.all_objects))
                if has_visible_objects:  # seen by camera and has objects viable for selection
                    self.make_col_visible(layer_col)
                else:
                    self.make_col_invisible(layer_col)

    def execute(self, context):
        if self.if_skippable(context.window_manager, self.bl_idname, self.as_keywords()):
            self.report({'INFO'}, 'No active properties changed, skipping operation')
            return {'CANCELLED'}

        # force depsgraph and matrix updates for 4.2
        # https://projects.blender.org/blender/blender/issues/125335
        context.evaluated_depsgraph_get()

        viable_objects = get_selected_objects(context)
        try:
            visible_objects = obj_main(context, viable_objects, **self.as_keywords())
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        self.collection_visibility(context, visible_objects, viable_objects)

        self.update_prev_data(context.window_manager, self.as_keywords(), self.bl_idname)

        return {'FINISHED'}
