#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy

from .op_coll import coll_iter
from .op_input import get_selected_objects


class NV_OT_RevealCollections(bpy.types.Operator):
    bl_idname = 'nview_lite.reset_collections'
    bl_label = 'Reveal All Collections'
    bl_description = 'Reveal all collections in this scene'
    bl_options = {'REGISTER', 'UNDO'}

    exclude: bpy.props.BoolProperty(
        name='View Layer',
        description='Include all collections in the view layer',
        options=set(),
        default=True
    )

    selectable: bpy.props.BoolProperty(
        name='Selectable',
        description='Make all scene collections selectable',
        options=set(),
        default=True
    )

    visible: bpy.props.BoolProperty(
        name='Visible',
        description='Make all scene collections visible',
        options=set(),
        default=True
    )

    viewport: bpy.props.BoolProperty(
        name='Viewport',
        description='Globally enable all scene collections in the viewport',
        options=set(),
        default=True
    )

    render: bpy.props.BoolProperty(
        name='Render',
        description='Globally enable all scene collections in renders',
        options=set(),
        default=True
    )

    def draw(self, _context):
        layout = self.layout
        layout.use_property_split = True
        column = layout.column(heading='Visibility')
        column.prop(self, 'exclude')
        column.prop(self, 'selectable')
        column.prop(self, 'visible')
        column.prop(self, 'viewport')
        column.prop(self, 'render')

    def execute(self, context):
        for layer_col in coll_iter(context.view_layer.layer_collection):
            if self.exclude:
                layer_col.exclude = False
            if self.visible:
                layer_col.hide_viewport = False
            if self.selectable:
                layer_col.collection.hide_select = False
            if self.viewport:
                layer_col.collection.hide_viewport = False
            if self.render:
                layer_col.collection.hide_render = False

        return {'FINISHED'}


class NV_OT_RevealObjects(bpy.types.Operator):
    bl_idname = 'nview_lite.reset_objects'
    bl_label = 'Reveal All Objects'
    bl_description = 'Reveal all objects in this scene'
    bl_options = {'REGISTER', 'UNDO'}

    selectable: bpy.props.BoolProperty(
        name='Selectable',
        description='Make all scene objects selectable',
        options=set(),
        default=True
    )

    visible: bpy.props.BoolProperty(
        name='Visible',
        description='Make all scene objects visible',
        options=set(),
        default=True
    )

    viewport: bpy.props.BoolProperty(
        name='Viewport',
        description='Globally enable all scene objects in the viewport',
        options=set(),
        default=True
    )

    render: bpy.props.BoolProperty(
        name='Render',
        description='Globally enable all scene objects in renders',
        options=set(),
        default=True
    )

    def draw(self, _context):
        layout = self.layout
        layout.use_property_split = True
        column = layout.column(heading='Visibility')
        column.prop(self, 'selectable')
        column.prop(self, 'visible')
        column.prop(self, 'viewport')
        column.prop(self, 'render')

    def execute(self, context):
        for obj in context.scene.objects:
            if self.viewport and obj.hide_viewport:
                obj.hide_viewport = False

            if self.selectable and obj.hide_select:
                obj.hide_select = False

            if self.render and obj.hide_render:
                obj.hide_render = False

            if self.visible and obj.hide_get():
                obj.hide_set(False)

        return {'FINISHED'}
