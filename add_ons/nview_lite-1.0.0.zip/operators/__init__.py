import bpy

from .operator_reset import NV_OT_RevealObjects, NV_OT_RevealCollections

from .operator_collections import NV_OT_ColVis
from .operator_mesh_select import NV_OT_SelectMesh
from .operator_mesh_visibility import NV_OT_MeshVis
from .operator_object_select import NV_OT_Select
from .operator_object_visibility import NV_OT_ObjVis


_register_order = [NV_OT_RevealObjects, NV_OT_RevealCollections,
                   NV_OT_ColVis, NV_OT_ObjVis, NV_OT_Select,
                   NV_OT_SelectMesh, NV_OT_MeshVis]


def register():
    for cls in _register_order:
        bpy.utils.register_class(cls)


def unregister():
    for cls in _register_order[::-1]:
        bpy.utils.unregister_class(cls)
