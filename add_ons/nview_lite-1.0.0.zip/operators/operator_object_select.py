#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

import logging

import bpy

from .methods.object_main import obj_main
from .op_input import get_selected_objects, OperatorSkip
from ..properties import ObjectProperties, SelectionProperties

log = logging.getLogger(__name__)


def obj_set_select(obj, val):
    try:
        obj.select_set(val)
    except Exception as e:  # cases when object isn't in view layer
        log.warning(obj.name + ' cannot be selected: ' + str(e))


class NV_OT_Select(bpy.types.Operator, OperatorSkip, ObjectProperties, SelectionProperties):
    bl_idname = 'nview_lite.select'
    bl_label = 'Deselect Objects Outside View'
    bl_description = 'Selects objects visible by the camera'
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        self.draw_selection_props(layout)
        self.draw_obj_props(layout)

    def execute(self, context):
        if self.if_skippable(context.window_manager, self.bl_idname, self.as_keywords()):
            self.report({'INFO'}, 'No active properties changed, skipping operation')
            return {'CANCELLED'}

        # force depsgraph and matrix updates for 4.2
        # https://projects.blender.org/blender/blender/issues/125335
        context.evaluated_depsgraph_get()

        selected_objects = get_selected_objects(context)
        try:
            visible_objects = obj_main(context, selected_objects, **self.as_keywords())
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        visible_objects_names = {vis_obj.name for vis_obj in visible_objects}

        for obj in selected_objects:
            is_visible = obj.name in visible_objects_names
            should_be_selected = is_visible != self.invert
            obj_set_select(obj, should_be_selected)

        self.update_prev_data(context.window_manager, self.as_keywords(), self.bl_idname)

        return {'FINISHED'}
