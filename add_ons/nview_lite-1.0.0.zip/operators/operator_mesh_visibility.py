#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy
import bmesh

from .methods.mesh_main import mesh_main
from .op_input import OperatorSkip
from ..properties import MeshProperties


class NV_OT_MeshVis(bpy.types.Operator, OperatorSkip, MeshProperties):
    bl_idname = 'nview_lite.mesh_visibility'
    bl_label = 'Show Mesh nView'
    bl_description = 'Hides geometry not seen by the camera'
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        self.draw_mesh_props(layout)

    def execute(self, context):
        if self.if_skippable(context.window_manager, self.bl_idname, self.as_keywords()):
            self.report({'INFO'}, 'No active properties changed, skipping operation')
            return {'CANCELLED'}

        # force depsgraph and matrix updates for 4.2
        # https://projects.blender.org/blender/blender/issues/125335
        context.evaluated_depsgraph_get()

        try:
            visible, _, _, all_of_them = mesh_main(context=context, mesh_object=context.edit_object, use_edit_mesh=True, **self.as_keywords())
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        visible_indices = {v.index for v in visible}

        for a in all_of_them:
            should_hide = a.index not in visible_indices
            a.hide_set(should_hide)

        bmesh.update_edit_mesh(context.edit_object.data, loop_triangles=False, destructive=False)

        self.update_prev_data(context.window_manager, self.as_keywords(), self.bl_idname)

        return {'FINISHED'}
