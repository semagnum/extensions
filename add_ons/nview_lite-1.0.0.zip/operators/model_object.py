#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


from mathutils import Vector

bound_box_base = [(-1.0, -1.0, -1.0), (-1.0, -1.0, 1.0), (-1.0, 1.0, 1.0), (-1.0, 1.0, -1.0),
                  (1.0, -1.0, -1.0), (1.0, -1.0, 1.0), (1.0, 1.0, 1.0), (1.0, 1.0, -1.0)]


def valid_bound_box(obj):
    return not all([obj.bound_box[0][0] == obj.bound_box[i][j] for i in range(8) for j in range(3)])


def light_probe_plane_bound_box(infl_dist: float, min_box_size):
    return [Vector((x * min_box_size, y * min_box_size, z * infl_dist)) for x, y, z in bound_box_base]


def light_probe_volume_bound_box(infl_dist: float, *args):
    return [Vector((x * infl_dist, y * infl_dist, z * infl_dist)) for x, y, z in bound_box_base]


def coalesce_bound_box(obj, min_box_size):
    """Generates bounding box based on object type and instanced data within it."""
    if obj.is_instancer and obj.instance_type == 'COLLECTION' and obj.instance_collection is not None:
        coll_instance_offset = Vector(obj.instance_collection.instance_offset)
        coll_instance_offset.negate()
        bound_boxes = [
                          [(coll_obj.matrix_world @ v) + coll_instance_offset for v in
                           coalesce_bound_box(coll_obj, min_box_size)]
                          for coll_obj
                          in obj.instance_collection.all_objects] \
                      + [obj.bound_box]
        x1, x2 = min((x for b in bound_boxes for x, _, _ in b)), max((x for b in bound_boxes for x, _, _ in b))
        y1, y2 = min((y for b in bound_boxes for _, y, _ in b)), max((y for b in bound_boxes for _, y, _ in b))
        z1, z2 = min((z for b in bound_boxes for _, _, z in b)), max((z for b in bound_boxes for _, _, z in b))
        coalesced_bound_box = [Vector((x1, y1, z1)), Vector((x1, y1, z2)), Vector((x1, y2, z2)), Vector((x1, y2, z1)),
                               Vector((x2, y1, z1)), Vector((x2, y1, z2)), Vector((x2, y2, z2)), Vector((x2, y2, z1))]
        return coalesced_bound_box
    elif obj.type == 'LIGHT':
        # sun lamp will be default size
        lamp_type = obj.data.type
        if lamp_type in {'POINT', 'SPOT'}:  # use radius
            size = obj.data.shadow_soft_size
            return [
                Vector((x * size, y * size, z * size))
                for x, y, z in bound_box_base
            ]
        elif lamp_type == 'AREA':  # use lamp size, depending on shape
            if obj.data.shape in {'SQUARE', 'DISK'}:
                size = obj.data.size / 2
                return [
                    Vector((x * size, y * size, z * min_box_size))
                    for x, y, z in bound_box_base
                ]
            else:
                return [
                    Vector((x * (obj.data.size / 2), y * (obj.data.size_y / 2), z * min_box_size))
                    for x, y, z in bound_box_base
                ]
    else:
        if valid_bound_box(obj):
            return [Vector((v[0], v[1], v[2])) for v in obj.bound_box]
        elif obj.type == 'LIGHT_PROBE':
            infl_dist = obj.data.influence_distance
            switch = {
                # Blender 4.1 renamed the types, so covering both here
                'CUBEMAP': light_probe_volume_bound_box, 'SPHERE': light_probe_volume_bound_box,
                'PLANAR': light_probe_plane_bound_box, 'PLANE': light_probe_plane_bound_box,
                'GRID': light_probe_volume_bound_box, 'VOLUME': light_probe_volume_bound_box,
            }
            return switch.get(obj.data.type)(infl_dist, min_box_size)
        return [Vector((x * min_box_size, y * min_box_size, z * min_box_size))
                for x, y, z in bound_box_base]


class ObjModel:
    __slots__ = 'obj', 'name', 'name_full', 'type', 'matrix_world', 'instance_collection', 'bound_box'
    bound_box_ind = [(x, y, z) for x in range(8)
                     for y in range(8) for z in range(8)
                     if x != y and x != z and y != z]

    def __init__(self, obj, min_bound_box):
        """
        Constructs Blender object (used for polymorphism)
        :param obj:
        """
        self.obj = obj
        self.name = obj.name
        self.name_full = obj.name_full
        self.type = obj.type
        self.matrix_world = obj.matrix_world
        self.instance_collection = obj.instance_collection
        min_box_size = min_bound_box / 2  # halved to take account for cube
        self.bound_box = coalesce_bound_box(obj, min_box_size)

    def is_in_obj(self, world_location: Vector):
        inverted_matrix = self.matrix_world.inverted()
        inverted_x, inverted_y, inverted_z = inverted_matrix @ world_location

        bound_box = self.bound_box

        x1, x2 = min((v[0] for v in bound_box)), max((v[0] for v in bound_box))
        y1, y2 = min((v[1] for v in bound_box)), max((v[1] for v in bound_box))
        z1, z2 = min((v[2] for v in bound_box)), max((v[2] for v in bound_box))

        return x1 <= inverted_x <= x2 and y1 <= inverted_y <= y2 and z1 <= inverted_z <= z2
