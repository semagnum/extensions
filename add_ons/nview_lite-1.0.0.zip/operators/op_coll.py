#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


def coll_iter(curr_coll):
    """
    Iterate through hierarchy of collections
    :param curr_coll: current collection
    :return: generator of collections
    """
    yield curr_coll
    for child in curr_coll.children:
        yield from coll_iter(child)


def find_coll_instancers(curr_coll):
    """
    Find all objects that instance collections
    :param curr_coll: current collection
    :return: generator of objects that instance collections
    """
    return (obj
            for obj in curr_coll.all_objects
            if obj.is_instancer and obj.instance_type == 'COLLECTION' and obj.instance_collection is not None)


def find_instanced_colls(curr_coll):
    """
    Iterate over collections instanced by objects
    :param curr_coll: current collection
    :return: generator of collections that are instanced by objects
    """
    return (o.instance_collection for o in find_coll_instancers(curr_coll))


# example: find_instanced_colls(context.view_layer.layer_collection)
def find_instanced_objs_in_colls(curr_coll):
    """
    Iterate over objects that are in collections instanced by objects
    :param curr_coll: current collection
    :return: generator of objects in collections instanced by objects
    """
    objs_dict = {}
    for coll in find_instanced_colls(curr_coll):
        for obj in coll.all_objects:
            if obj not in objs_dict:
                objs_dict[obj] = True
                yield obj

