#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.


import bpy

from ..operators import NV_OT_SelectMesh, NV_OT_MeshVis


class NV_PT_MeshOperators(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_label = 'If Not Seen by the Camera...'
    bl_region_type = 'UI'
    bl_category = 'nView'
    bl_context = 'mesh_edit'

    def draw(self, context):
        layout = self.layout
        layout.operator(NV_OT_SelectMesh.bl_idname, text='Deselect', icon='RESTRICT_SELECT_OFF')
        layout.operator(NV_OT_MeshVis.bl_idname, text='Hide', icon='HIDE_OFF')
