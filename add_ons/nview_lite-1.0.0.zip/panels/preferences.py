import bpy

from .NV_Mesh import NV_PT_MeshOperators
from .NV_Object import NV_PT_Operators, NV_PT_ResetOperators
from .. import __package__ as base_package

PANEL_IDS = ('NV_PT_Operators', 'NV_PT_ResetOperators', 'NV_PT_MeshOperators')
PANEL_CLASSES = (NV_PT_Operators, NV_PT_ResetOperators, NV_PT_MeshOperators)


def update_helper_category_name(self, _context):
    """Unregisters all panels, sets preferences category name, and re-registers panels.

    :param self: OperatorProperties instance, in this case, preferences properties
    :param _context: Blender context
    """
    assert len(PANEL_IDS) == len(PANEL_CLASSES)

    for pid, panel in zip(PANEL_IDS, PANEL_CLASSES):
        is_panel_registered = hasattr(bpy.types, pid)
        if not is_panel_registered:
            continue

        try:
            bpy.utils.unregister_class(getattr(bpy.types, pid))

            panel.bl_category = self.category_name
            bpy.utils.register_class(panel)
        except Exception:
            raise RuntimeError('Panel failed to re-register:' + pid)


class NV_Preferences(bpy.types.AddonPreferences):
    bl_idname = base_package

    category_name: bpy.props.StringProperty(
        name='Category',
        description='Category the add-on panels will be listed under.',
        default='nView',
        update=update_helper_category_name
    )
    """Category the panel will be under."""

    use_dialog_box: bpy.props.BoolProperty(
        name='Use Dialog Box',
        description='Show properties upon clicking nView operator buttons, and only execute after clicking OK',
        default=False,
        options={'HIDDEN'},
    )
    """Allows properties to show upon clicking nView operator, to tweak parameters before running."""

    def draw(self, _context):
        layout = self.layout
        layout.prop(self, 'category_name')
        layout.prop(self, 'use_dialog_box')
