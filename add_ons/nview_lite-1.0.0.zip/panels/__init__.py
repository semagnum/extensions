import bpy

from .NV_Mesh import NV_PT_MeshOperators
from .NV_Object import NV_PT_Operators, NV_PT_ResetOperators
from .preferences import NV_Preferences, update_helper_category_name

_register_order = [NV_Preferences, NV_PT_Operators, NV_PT_ResetOperators, NV_PT_MeshOperators]


def register():
    for cls in _register_order:
        bpy.utils.register_class(cls)


def unregister():
    for cls in _register_order[::-1]:
        bpy.utils.unregister_class(cls)
