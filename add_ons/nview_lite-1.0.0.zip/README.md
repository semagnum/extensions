## What does the nView Blender Addon do?

Select and toggle visibility of objects based on visibility from camera or visibility in reflections.

## The panels

Go to the 3D view and open the right-hand tools (default shortcut is 'n').
Select the 'nView' tab. There are panels available both in object mode and mesh edit mode.

### Object Mode

Here you can find the operations to act on objects in your scene. 
Note that these operate only on the objects you select.
This allows you to select only a few objects to operate on for speed.
But if you wish to operate on all objects or objects of a certain type,
you can use Blender's internal commands to select all (Ctrl+A) or select by type (Shift+G) respectively.

Each operation's parameters can be found in the Redo panel of the operators.
You will find these in the bottom-left corner of the 3D view you operate in
(but you can also press F9 to reveal it after an operation).

Let's go over what each part does, and what unique parameters are available in their operator redo panels:

*   Deselect Objects: deselects all objects in your current selection that are out of the camera's view.
    *   In the redo panel, you can invert your selection to only select objects outside of camera view.  
        
*   Hide Objects: hides all objects in your current selection that are out of the camera's view.
    *   In the redo panel, you can tweak which visibility attributes are affected, including viewport and render visibility, as well as baking the visibility to keyframes.
*   Hide Collections: if all selected objects in a given collection are invisible to the camera, the entire collection is hidden.
    *   In the redo panel, you can tweak which attributes are affected, including view layer, viewport, and render visibility.

In the clean panel, you have convenience operators to help you with undoing operations:

*   **Show All Objects**: shows all objects in your scene. In the redo panel, you can tweak which visibility attributes are reset.
*   **Show All Collections**: shows all collections in your scene's current view layer. In the redo panel, you can tweak which visibility attributes are reset.

#### Clean Panel

This panel has some convenience operators such as revealing all objects and collections in your scene.

### Mesh Edit Mode

Here you can find the operations to act on geometry for a given mesh.
Note that these operate only on the geometry you select.
These operations also work in vertex, edge, and face selection modes.

*   Deselect: deselects geometry in your current selection that are out of the camera's view.
    *   In the redo panel, you can invert your selection to only select geometry outside of camera view.
*   **Hide**: hides geometry in your current selection. Note that this is only temporary to edit mode.
*   **Choose Camera**: This is where you select which camera nView uses for visibility checks, the same way as you would in object mode.

## Shared Parameters

Many of the operation parameters are shared between them, so I will go over them all together here.
Note that while most are shared, not all.

### Animation

With one checkbox, you can query visibility over a given frame range!
If an object is visible at any point in that frame range, it will be counted as visible.

### Methods

Based on culling algorithms, these are methods you can choose from to determine
whether objects or geometry is visible from the camera.
The default is frustum, which is useful for most cases as well as very fast.

#### Frustum

If an object's bounds are within a camera's view frustum
(excluding objects outside the near and far clipping planes), then it is considered visible.
This may include objects that are within the frustum but occluded/hidden by other objects.

This method has a setting to increase the margin beyond the frustum, to add padding for objects about to enter camera view.

#### Backface (mesh edit mode only)

Only faces or vertices facing the camera are visible (note this method does not work on edges).  

#### Distance (object mode only)

Only keeps objects visible within a user-specified distance from the camera.