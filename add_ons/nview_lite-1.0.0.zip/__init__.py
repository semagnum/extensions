#     nView Lite, Blender add-on that manages scene data based on visibility from the camera.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

if 'bpy' in locals():
    import importlib
    import os
    import sys
    import logging
    import types

    log = logging.getLogger(__name__)

    def reload_package(package):
        assert (hasattr(package, '__package__'))
        fn = package.__file__
        fn_dir = os.path.dirname(fn) + os.sep
        module_visit = {fn}
        del fn

        def reload_recursive_ex(module):
            module_iter = (
                module_child
                for module_child in vars(module).values()
                if isinstance(module_child, types.ModuleType)
            )
            for module_child in module_iter:
                fn_child = getattr(module_child, '__file__', None)
                if (fn_child is not None) and fn_child.startswith(fn_dir) and fn_child not in module_visit:
                    module_visit.add(fn_child)
                    reload_recursive_ex(module_child)

            importlib.reload(module)
            log.debug('Reloading: ' + module.__name__)

        return reload_recursive_ex(package)

    reload_package(sys.modules[__name__])

import bpy

from . import Constants, properties, operators, panels

from .Constants import ACTIVE_CAMERA_OPTION, CUSTOM_CAMERA_OPTION

from .operators import methods
from .operators.methods import mesh_main, object_main

from .operators import register as operators_register, unregister as operators_unregister
from .panels import (
    register as panels_register,
    unregister as panels_unregister,
    update_helper_category_name as update_category
)

wm_props = [
    ('prev_run_data', bpy.props.StringProperty(
        default='{}',
        options={'HIDDEN'},
    )),
    ('prev_run_operator', bpy.props.StringProperty(
        default='',
        options={'HIDDEN'},
    )),
]


def register():
    bpy.utils.register_class(properties.CameraElement)
    bpy.utils.register_class(properties.NV_UL_Cameras)

    window_manager = bpy.types.WindowManager

    for name, prop in wm_props:
        setattr(window_manager, name, prop)

    operators_register()
    panels_register()

    # force category name update - otherwise Blender registers with default name
    update_category(bpy.context.preferences.addons[__package__].preferences, None)


def unregister():
    panels_unregister()
    operators_unregister()

    bpy.utils.unregister_class(properties.NV_UL_Cameras)
    bpy.utils.unregister_class(properties.CameraElement)


if __name__ == '__main__':
    register()
