#     Copy Render Command, Blender add-on that generates command line command to render a file.
#     Copyright (C) 2024 Spencer Magnusson
#     semagnum@gmail.com
#
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <https://www.gnu.org/licenses/>.

import subprocess


def generate_command(blender_binary_path, blend_filepath, is_animation: bool, factory_reset: bool,
                     frame_start=None, frame_end=None, frame_step=None, threads=None,
                     frame_current=None,
                     scene=None, engine=None,
                     ):
    blender_cmd = [blender_binary_path, '--background', blend_filepath]

    if factory_reset:
        blender_cmd += ['--factory-startup']

    if is_animation:

        if frame_start is not None:
            blender_cmd += ['--frame-start', frame_start]
        if frame_end is not None:
            blender_cmd += ['--frame-end', frame_end]
        if frame_step is not None:
            blender_cmd += ['--frame-jump', frame_step]

        if threads is not None:
            blender_cmd += ['--threads', threads]

    if scene is not None:
        blender_cmd += ['--scene', scene]

    if engine is not None:
        blender_cmd += ['--engine', engine]

    if not is_animation:
        blender_cmd += ['-f', frame_current]
    else:
        blender_cmd += ['-a']

    return subprocess.list2cmdline(blender_cmd)