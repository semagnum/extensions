"""BLint Offline allows users to run BLint from the command line, fixing files if necessary.

This enables BLint for continuous integration and automated testing."""
