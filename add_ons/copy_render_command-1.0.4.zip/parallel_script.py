import sys

import bpy

BORDER = '-' * 16
ENABLED = BORDER + 'PARALLEL RENDERING ENABLED' + BORDER
NOT_ENABLED = BORDER + 'SERIAL RENDERING' + BORDER


def enable_parallel_rendering():
    for scene in bpy.data.scenes:
        if (
            scene.render.image_settings.file_format == 'FFMPEG' or 
            (getattr(scene.render.image_settings, 'media_type', None) == 'VIDEO')
        ):
            print('Video rendering not supported, skipping parallel support for scene', scene.name)
            continue
        scene.render.use_overwrite = False
        scene.render.use_placeholder = True


if __name__ == '__main__':
    # check that '-a' or '-render-anim' in command arguments
    if not ('-a' in sys.argv or '--render-anim' in sys.argv):
        print(NOT_ENABLED)
        print('Run with -a or -render-anim to enable parallel rendering')
        print('-' * len(NOT_ENABLED))

    # set for all scenes, in case of a render override
    else:
        enable_parallel_rendering()
        print(ENABLED)
        print('Other shells can also render with the same command')
        print('-' * len(ENABLED))
