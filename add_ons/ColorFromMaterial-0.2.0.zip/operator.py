# Copyright (C) 2024 Spencer Magnusson
# semagnum@gmail.com
# Created by Spencer Magnusson
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

import bpy
from mathutils import Vector

from . import config, node_eval as node


def _valid_material(material):
    return not material.is_grease_pencil and material.library is None and getattr(material, 'use_nodes', True)


def set_material(material, albedo: bool, metallic: bool, roughness: bool):
    if not _valid_material(material):
        return
    
    node_tree = material.node_tree
    output = next((node for node in node_tree.nodes if 'Output' in node.bl_idname), None)

    if output is not None:
        for tmp_node in node_tree.nodes:
            if getattr(tmp_node, 'node_tree', False):
                config.compile_node(tmp_node)

        if albedo:
            material.diffuse_color = node.assert_color(
                node.evaluate_node(
                    output, config.ALBEDO_MAP, Vector((0.8, 0.8, 0.8, 1.0))
                )
            )
        if roughness:
            material.roughness = node.assert_float(node.evaluate_node(output, config.ROUGHNESS_MAP, 0.5))

        if metallic:
            material.metallic = node.assert_float(node.evaluate_node(output, config.METALLIC_MAP, 0.0))


class CFMOperator(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}

    analyze_albedo: bpy.props.BoolProperty(
        name='Update Albedo',
        default=True,
    )

    analyze_metallic: bpy.props.BoolProperty(
        name='Update Metallic',
        default=True,
    )

    analyze_roughness: bpy.props.BoolProperty(
        name='Update Roughness',
        default=True,
    )


class SelectedObjectsOperator(CFMOperator):
    """Sets all selected object's viewport display properties."""
    bl_idname = 'object.selected_objects_nodes_to_viewport'
    bl_label = 'Set Selected Objects\' Nodes To Viewport Display'

    def execute(self, context):
        materials = {slot.material
                     for obj in context.selected_objects
                     for slot in obj.material_slots
                     if slot.material is not None}

        group_nodes = {
            group_node
            for material in materials
            for group_node in material.node_tree.nodes
            if getattr(group_node, 'node_tree', False)
        }
        for group_node in group_nodes:
            config.compile_node(group_node)

        for material in materials:
            set_material(material, self.analyze_albedo, self.analyze_metallic, self.analyze_roughness)

        return {'FINISHED'}


class ActiveMaterialOperator(CFMOperator):
    """Sets current object's active material's viewport display properties."""
    bl_idname = 'object.active_material_nodes_to_viewport'
    bl_label = 'Active Material Nodes To Viewport Display'

    @classmethod
    def poll(cls, context):
        return context.active_object.active_material is not None and _valid_material(context.active_object.active_material)

    def execute(self, context):
        material = context.active_object.active_material
        group_nodes = {
            group_node
            for group_node in material.node_tree.nodes
            if getattr(group_node, 'node_tree', False)
        }
        for group_node in group_nodes:
            config.compile_node(group_node)
        set_material(material, self.analyze_albedo, self.analyze_metallic, self.analyze_roughness)

        return {'FINISHED'}


class ActiveObjectOperator(CFMOperator):
    """Sets current object's material's viewport display properties."""
    bl_idname = 'object.active_object_nodes_to_viewport'
    bl_label = 'Active Objects\' Material Nodes To Viewport Display'

    @classmethod
    def poll(cls, context):
        return (
            context.active_object is not None and
            context.active_object.material_slots
        )

    def execute(self, context):
        materials = {slot.material
                     for slot in context.active_object.material_slots
                     if slot.material is not None}

        group_nodes = {
            group_node
            for material in materials
            for group_node in material.node_tree.nodes
            if getattr(group_node, 'node_tree', False)
        }
        for group_node in group_nodes:
            config.compile_node(group_node)

        for material in materials:
            set_material(material, self.analyze_albedo, self.analyze_metallic, self.analyze_roughness)

        return {'FINISHED'}


class AllMaterialsOperator(CFMOperator):
    """Sets all materials' viewport display properties."""
    bl_idname = 'object.all_material_nodes_to_viewport'
    bl_label = 'All Material Nodes To Viewport Display'

    def execute(self, _context):
        group_nodes = {
            group_node
            for material in bpy.data.materials
            for group_node in material.node_tree.nodes
            if getattr(group_node, 'node_tree', False)
        }
        for group_node in group_nodes:
            config.compile_node(group_node)
        
        for material in bpy.data.materials:
            set_material(material, self.analyze_albedo, self.analyze_metallic, self.analyze_roughness)

        return {'FINISHED'}


class ActiveMaterialNodeOperator(CFMOperator):
    """Sets all materials' viewport display properties."""
    bl_idname = 'object.active_material_from_active_node_to_viewport'
    bl_label = 'Active Material Node To Viewport Display'
    bl_description = ('Set active material\'s viewport display attributes '
                      'based on currently selected node (only select one!)')

    @classmethod
    def poll(cls, context):
        material = context.active_object.active_material
        return (
            material is not None and
            _valid_material(material) and
            len([
                node
                for node in material.node_tree.nodes
                if node.select
            ]) == 1
        )

    def execute(self, context):
        material = context.active_object.active_material
        active_node = [n for n in material.node_tree.nodes if n.select][0]
        
        if getattr(active_node, 'node_tree', False):
            config.compile_node(curr_node)

        if self.analyze_albedo:
            material.diffuse_color = node.assert_color(
                node.evaluate_node(
                    active_node, config.ALBEDO_MAP, Vector((0.8, 0.8, 0.8, 1.0))
                )
            )
        if self.analyze_roughness:
            material.roughness = node.assert_float(node.evaluate_node(active_node, config.ROUGHNESS_MAP, 0.5))

        if self.analyze_metallic:
            material.metallic = node.assert_float(node.evaluate_node(active_node, config.METALLIC_MAP, 0.0))

        return {'FINISHED'}
