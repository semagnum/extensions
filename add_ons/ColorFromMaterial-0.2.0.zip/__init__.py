# Copyright (C) 2024 Spencer Magnusson
# semagnum@gmail.com
# Created by Spencer Magnusson
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

if 'bpy' in locals():
    import importlib
    reloadable_modules = [
        'node_eval',
        'custom_node_eval',
        'config',
        'operator',
        'panel'
    ]
    for module_name in reloadable_modules:
        if module_name in locals():
            importlib.reload(locals()[module_name])

import bpy

from . import config, node_eval, custom_node_eval, operator, panel


bl_info = {
    "name": 'Material Viewport Color from Nodes',
    "author": 'Spencer Magnusson',
    "version": (0, 2, 0),
    "blender": (4, 2, 0),
    "description": 'Sets material viewport display attributes based on the node tree',
    "location": 'Object Material Properties',
    "support": 'COMMUNITY',
    "category": 'Material'
}

addon_classes = [
    operator.AllMaterialsOperator,
    operator.ActiveObjectOperator,
    operator.SelectedObjectsOperator,
    operator.ActiveMaterialOperator,
    operator.ActiveMaterialNodeOperator,
    panel.CM_PT_ObjectColorFromMaterial,
]


def register():
    """Registers operators and properties."""

    bpy.types.WindowManager.cfm_analyze_albedo = bpy.props.BoolProperty(
        name='Update Albedo',
        description='Detects and updates for viewport material\'s albedo property',
        default=True,
    )
    bpy.types.WindowManager.cfm_analyze_metallic = bpy.props.BoolProperty(
        name='Update Metallic',
        description='Detects and updates for viewport material\'s metallic property',
        default=True,
    )
    bpy.types.WindowManager.cfm_analyze_roughness = bpy.props.BoolProperty(
        name='Update Roughness',
        description='Detects and updates viewport material\'s roughness property',
        default=True,
    )

    for cls in addon_classes:
        bpy.utils.register_class(cls)

    if bpy.app.background:
        import logging
        logger = logging.getLogger(__name__)
        logger.warning('Background mode detected, ColorFromMaterial shader node evaluation will not work as expected')
        logger.warning('You can force compilation by manually calling:')
        logger.warning('`bl_ext.<repo>.ColorFromMaterial.config._compile_maps()`')
    else:
        bpy.app.timers.register(config._compile_maps)

def unregister():
    """Unregisters operators and properties."""

    for cls in addon_classes[::-1]:
        bpy.utils.unregister_class(cls)

    del bpy.types.WindowManager.cfm_analyze_albedo
    del bpy.types.WindowManager.cfm_analyze_metallic
    del bpy.types.WindowManager.cfm_analyze_roughness


if __name__ == '__main__':
    register()
