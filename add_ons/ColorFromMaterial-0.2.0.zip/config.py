# Copyright (C) 2023 Spencer Magnusson
# semagnum@gmail.com
# Created by Spencer Magnusson
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

from . import custom_node_eval as custom

import bpy

ALPHA_THRESHOLD = 0.7

FIRST_INPUT = ('inputs', 0)

UNIVERSAL_MAP = {
    'ShaderNodeRGB': ('outputs', 0),
    'ShaderNodeValue': ('outputs', 0),
    'ShaderNodeMapRange': FIRST_INPUT,
    'ShaderNodeSeparateColor': FIRST_INPUT,
    'NodeGroupOutput': FIRST_INPUT,
    'ShaderNodeOutputMaterial': FIRST_INPUT,
    'ShaderNodeBrightContrast': FIRST_INPUT,
    'ShaderNodeGamma': FIRST_INPUT,
    'ShaderNodeHueSaturation': ('inputs', 4),
    'ShaderNodeInvert': ('inputs', 1),
    'ShaderNodeRGBCurve': ('inputs', 1),
    'ShaderNodeClamp': custom.clamp_node,
    'ShaderNodeTexImage': custom.image_node,
    'ShaderNodeTexEnvironment': custom.image_node,
    'ShaderNodeValToRGB': custom.color_ramp,
    'ShaderNodeMix': custom.mix_node,
    'ShaderNodeAddShader': custom.add_shader,
    'ShaderNodeMixShader': custom.mix_shader,
    'ShaderNodeShaderToRGB': FIRST_INPUT,
    'ShaderNodeRGBToBW': FIRST_INPUT,
    'ShaderNodeSeparateXYZ': FIRST_INPUT,
}

ALBEDO_MAP = {}

METALLIC_MAP = {
    'ShaderNodeBsdfMetallic': 1.0,
    'ShaderNodeBsdfGlass': 1.0,
    'ShaderNodeBsdfRefraction': 1.0,
}

ROUGHNESS_MAP = {
    'ShaderNodeBsdfToon': ('inputs', 1),
}


def _find_match(idx_input_names, exact_matches, keywords):
    idx = next((
        idx
        for match in exact_matches
        for idx, name in idx_input_names
        if name == match
    ), None)
    if idx is not None:
        return idx
    
    return next((
        idx
        for match in keywords
        for idx, name in idx_input_names
        if match in name
    ), None)


def compile_node(node):
    """Attempt to compile supported sockets for a specific node."""
    node_id = node.node_tree.name if getattr(node, 'node_tree', False) else node.bl_idname

    idx_input_names = tuple((idx, input_socket.name) for idx, input_socket in enumerate(node.inputs))

    albedo_idx = _find_match(idx_input_names, ('Base Color', 'Color'), ())
    if albedo_idx is not None:
        ALBEDO_MAP[node_id] = ('inputs', albedo_idx)

    metallic_idx = _find_match(idx_input_names, ('Metallic', 'Metalness'), ('Metallic', 'Metalness'))
    if metallic_idx is not None:
        METALLIC_MAP[node_id] = ('inputs', metallic_idx)

    roughness_idx = _find_match(idx_input_names, ('Roughness',), ('Roughness',))
    if roughness_idx is not None:
        ROUGHNESS_MAP[node_id] = ('inputs', roughness_idx)


def _compile_maps():
    """Checks all shader node types, attempts to compile supported sockets."""
    import inspect

    with bpy.data.temp_data() as temp_data:
        new_test_material = temp_data.materials.new('test_material_TO_DELETE')
        node_tree = new_test_material.node_tree

        # add all supported shader nodes
        for bpy_type in dir(bpy.types):
            real_type = getattr(bpy.types, bpy_type)
            if inspect.isclass(real_type) and issubclass(real_type, bpy.types.ShaderNode):
                try:
                    node = node_tree.nodes.new(bpy_type)
                except:
                    pass
        
        for node in node_tree.nodes:
            compile_node(node)

    # add these afterward, as a forced override
    ALBEDO_MAP.update(UNIVERSAL_MAP)
    METALLIC_MAP.update(UNIVERSAL_MAP)
    ROUGHNESS_MAP.update(UNIVERSAL_MAP)

    return None
