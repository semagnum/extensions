# Copyright (C) 2023 Spencer Magnusson
# semagnum@gmail.com
# Created by Spencer Magnusson
#     This program is free software: you can redistribute it and/or modify
#     it under the terms of the GNU General Public License as published by
#     the Free Software Foundation, either version 3 of the License, or
#     (at your option) any later version.
#     This program is distributed in the hope that it will be useful,
#     but WITHOUT ANY WARRANTY; without even the implied warranty of
#     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#     GNU General Public License for more details.
#     You should have received a copy of the GNU General Public License
#     along with this program.  If not, see <http://www.gnu.org/licenses/>.

import bpy
from mathutils import Vector


def assert_float(val) -> float:
    try:
        _iter_test = iter(val)
    except TypeError:
        return val
    else:  # is a color, exclude alpha channel
        return max(val[:-1])


def assert_color(val) -> Vector:
    try:
        _iter_test = iter(val)
    except TypeError:
        return Vector((val, val, val, 1.0))
    else:
        return Vector(val)  # force conversion from bpy props


def evaluate_socket(curr_socket, node_key: dict, default_val):
    """Get value from node socket - either evaluating the default value or following the link.

    :param curr_socket: node socket object.
    :param node_key: config key of node ids and which sockets to retrieve the float value.
    :param default_val: default float value if no nodes match.
    :return: value from socket
    """
    if curr_socket.is_linked and not curr_socket.is_output:
        next_node = curr_socket.links[0].from_node
        if next_node.bl_idname != 'NodeGroupInput':
            return evaluate_node(next_node, node_key, default_val)
    elif hasattr(curr_socket, 'default_value'):
        return curr_socket.default_value

    return default_val


def evaluate_node(curr_node: bpy.types.Node, node_key: dict, default_val):
    """Get value from node socket - either evaluating the default value or following the link.

    :param curr_node: node object.
    :param node_key: config key of node ids and which sockets to retrieve the float value.
    :param default_val: default float value if no nodes match.
    :return: value from socket
    
    """
    visited = set()
    nodes_to_check = [curr_node]
    value = default_val

    while nodes_to_check:
        # popping takes the LAST element,
        # so appended elements are checked first and higher priority
        curr_node = nodes_to_check.pop()
        if curr_node in visited:
            continue
        visited.add(curr_node)

        is_group_node = getattr(curr_node, 'node_tree', False)

        result = node_key.get(curr_node.node_tree.name if is_group_node else curr_node.bl_idname, None)
        if result is not None:
            if callable(result):
                value = result(curr_node, node_key, default_val)
            elif isinstance(result, float):
                value = result
            else:  # follow socket
                direction, albedo_idx = result
                curr_socket = getattr(curr_node, direction)[albedo_idx]

                if curr_socket.is_linked and not curr_socket.is_output:
                    next_node = curr_socket.links[0].from_node
                    if next_node.bl_idname != 'NodeGroupInput':
                        nodes_to_check.append(next_node)
                elif hasattr(curr_socket, 'default_value'):
                    value = curr_socket.default_value
        elif is_group_node:
            node_tree = curr_node.node_tree
            output_node = next((node for node in node_tree.nodes if 'Output' in node.bl_idname), None)

            # add group output node last, so it is checked first
            # then add any input nodes
            nodes_to_check += list({
                link.from_node
                for node_input in reversed(curr_node.inputs)
                for link in node_input.links
            })
            nodes_to_check.append(output_node)
            continue

        if value != default_val:
            break
    
    return value